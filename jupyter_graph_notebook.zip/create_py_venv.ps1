# This script sets up a python virtual environment.  It is meant to be used with the 'graph_notebook_requirements.txt 
# to set up a Jupyter Notebook with the AWS Graph Notebook software, but can be used for any other venv with different
# sets of requirements
# 
# Change CODING_DIRECTORY to your projects folder 
# example command:
#
# .\create_py_venv.ps1 graph_dev_test C:\Python\Python394-64\python.exe ..\graph_notebook_requrements.txt
#

$CODING_DIRECTORY = Resolve-Path "." | select -ExpandProperty Path
$PROJECT_NAME = [String]$args[0]
$PYTHON_EXECUTABLE = [String]$args[1]
$REQUIREMENTS = [String]$args[2]
$Full_Requirements_Path = Resolve-Path $REQUIREMENTS | select -ExpandProperty Path

$MyEditor = "VSCodium"

$PROJECT_DIRECTORY = "$CODING_DIRECTORY\$PROJECT_NAME"
$VENV_NAME = ".venv-$PROJECT_NAME"
$VENV_DIRECTORY = "$CODING_DIRECTORY\$VENV_NAME"
# Check if code directory exists, exit if it does not
if (-Not $(Test-Path $CODING_DIRECTORY)) {
Write-Error `
-Message "ERROR: Path $CODING_DIRECTORY does not exist. Please correct the path and start again" `
-Category InvalidData
}
# Create the project folder if it doesn't already exist
if (-Not $(Test-Path $PROJECT_DIRECTORY)) {
Write-Host "Creating directory $PROJECT_DIRECTORY"
[Void](New-Item -ItemType Directory -Path $PROJECT_DIRECTORY)
if (-Not $(Test-Path $PROJECT_DIRECTORY)) {
Write-Error `
-Message "Path $PROJECT_DIRECTORY couldn't be created" `
-Category InvalidData
}
}
# Create the virtual environment if it doesn't already exist
if (-Not $(Test-Path $VENV_DIRECTORY)) {
Write-Host "Creating environment $VENV_NAME"
& $PYTHON_EXECUTABLE -m pip install --upgrade pip
& $PYTHON_EXECUTABLE -m venv $VENV_DIRECTORY
}
# Move to venv folder and run the activation script
Set-Location "$VENV_DIRECTORY\Scripts"
.\Activate.ps1
# Move to the project folder and launch VS Code
Set-Location $VENV_DIRECTORY
& .\Scripts\python -m pip install --upgrade pip
& .\Scripts\pip install -r $Full_Requirements_Path 
Write-Host "Launching Editor"
& $MyEditor $PROJECT_DIRECTORY 
Write-Host "Starting Jupyter Notebook"
& .\Scripts\python -m graph_notebook.start_notebook --notebooks-dir $PROJECT_DIRECTORY