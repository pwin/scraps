# jupyter_graph_notebook
This provides a script and requirements file to set up a Python venv and the packages to run the AWS graph notebook (a Jupyter notebook)
